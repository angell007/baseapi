<table>
    <thead>
        <tr>
            <th>Estante:</th>
            <th>Dirección:</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><?php echo e($items->name); ?></td>
            <td><?php echo e($items->address); ?></td>
        </tr>
    </tbody>
</table>


<table class="table table-hover mb-0">
    <thead>
        <tr>
            <th>Creado:</th>
            <th>Actualizado:</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td class="text"><label class="text"><?php echo e($items->created_at); ?></label></td>
            <td class="text"><label class="text"><?php echo e($items->updated_at); ?></label></td>
        </tr>
    </tbody>
</table>



<table class="table table-hover mb-0">
    <thead>
        <tr>
            <th>Elemento</th>
            <th>Referencia</th>
            <th>Cantidad</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $items->elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if( $item->quantities->quantity == 0 ): ?>
        <tr>
            <td class="text"><label class="text"><?php echo e($item->name); ?></label></td>
            <td class="text"><label class="text"><?php echo e($item->reference); ?></label></td>
            <td class="text"><label class="badge badge-light-primary"><?php echo e($item->quantities->quantity); ?></label>
        </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\laragon\www\baseApi\resources\views/exports/inventory.blade.php ENDPATH**/ ?>