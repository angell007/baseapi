<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Templete</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title></title>
    <style type="text/css">
        div.noticia {
            /* width: 50%; */
            /* margin: 2px auto; */
            /* background-color: rgb(0, 0, 0); */
            /* color: #fff; */
            /* padding: 15px; */
        }

        div.noticia img.derecha {
            float: right;
            /* margin-left: 15px; */
        }

        div.reset {
            clear: both;
        }
    </style>
</head>

<body style="margin: 0; padding: 0; line-height: .1; font-size: 13pt;">

    <table width="100%">
        <tbody width="100%">
            <?php for($i = 0; $i < 10; $i++): ?> <tr width="100%">
                <td height="70px" width="" if>
                    <div class="noticia">
                        <img class="derecha" width="95px"
                            src="<?php echo e(public_path()); ?>/imgs/items/<?php echo e($elemetn->qr); ?>.png"
                            alt="">
                        <aside width="100%">
                            <p><?php echo e($elemetn->name); ?></p>
                            <p><?php echo e($elemetn->sku); ?></p>
                            <p><?php echo e($elemetn->sheet_size); ?></p>
                            <p><?php echo e($elemetn->packing); ?></p>
                        </aside>
                        <div class="reset"></div>
                    </div>
                </td>
                <td height="70px" width="">
                    <div class="noticia">
                        <img class="derecha" width="95px"
                            src="<?php echo e(public_path()); ?>/imgs/items/<?php echo e($elemetn->qr); ?>.png"
                            alt="">
                        <aside width="100%">
                            <p><?php echo e($elemetn->name); ?></p>
                            <p><?php echo e($elemetn->sku); ?></p>
                            <p><?php echo e($elemetn->sheet_size); ?></p>
                            <p><?php echo e($elemetn->packing); ?></p>
                        </aside>
                        <div class="reset"></div>
                    </div>
                </td>
                </tr>
                <?php endfor; ?>
        </tbody>
    </table>

</body>

</html><?php /**PATH C:\laragon\www\baseApi\resources\views/pdfs/printqr.blade.php ENDPATH**/ ?>